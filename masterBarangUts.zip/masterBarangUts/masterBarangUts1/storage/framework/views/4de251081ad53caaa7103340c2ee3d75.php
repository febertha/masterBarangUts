<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="contact_info">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="contact_info_container d-flex flex-lg-row flex-column justify-content-between align-items-between">

                            <!-- Contact Item -->
                            <div class="contact_info_item d-flex flex-row align-items-center justify-content-start">
                                <div class="contact_info_content">
                                    <div class="contact_info_title"><i class="bi bi-telephone"></i>  Phone</div>
                                    <div class="contact_info_text">+62812 9876 543</div>
                                </div>
                            </div>

                            <!-- Contact Item -->
                            <div class="contact_info_item d-flex flex-row align-items-center justify-content-start">
                                <div class="contact_info_content">
                                    <div class="contact_info_title"><i class="bi bi-envelope"></i> Email</div>
                                    <div class="contact_info_text">cake-house@gmail.com</div>
                                </div>
                            </div>

                            <!-- Contact Item -->
                            <div class="contact_info_item d-flex flex-row align-items-center justify-content-start">
                                <div class="contact_info_content">
                                    <div class="contact_info_title"><i class="bi bi-geo-alt"></i> Address</div>
                                    <div class="contact_info_text">298, Surabaya, Jawa Timur, Indonesia 'toko pusat'</div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div><br><br><br><br><br><br><br>

        <!-- Contact Form -->

        <div class="contact_form">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="contact_form_container">
                            <h3>Get in Touch</h3><br>

                            <form action="#" id="contact_form">
                                <div class="contact_form_inputs d-flex flex-md-row flex-column justify-content-between align-items-between">
                                    <input type="text" id="contact_form_name" class="contact_form_name input_field" placeholder="Your name" required="required" data-error="Name is required.">
                                </div><br>
                                <div class="contact_form_inputs d-flex flex-md-row flex-column justify-content-between align-items-between">
                                    <input type="text" id="contact_form_email" class="contact_form_email input_field" placeholder="Your email" required="required" data-error="Email is required.">
                                </div><br>
                                <div class="contact_form_inputs d-flex flex-md-row flex-column justify-content-between align-items-between">
                                    <input type="text" id="contact_form_phone" class="contact_form_phone input_field" placeholder="Your phone number">
                                </div><br>
                                <div class="contact_form_text">
                                    <textarea id="contact_form_message" class="text_field contact_form_message" name="message" rows="4" placeholder="Message" required="required" data-error="Please, write us a message."></textarea>
                                </div><br>
                                <div class="contact_form_button">
                                    <button type="submit" class="button contact_submit_button">Send Message</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <div class="panel"></div>
        </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Python\00 - Template\SEMESTER 4\masterBarangUts1\resources\views/contactUs.blade.php ENDPATH**/ ?>