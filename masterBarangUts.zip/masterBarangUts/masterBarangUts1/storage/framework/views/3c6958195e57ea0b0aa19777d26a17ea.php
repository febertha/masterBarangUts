<?php $__env->startSection('content'); ?>
    <div class="container-sm my-5">
        <div class="row justify-content-center">
            <div class="p-5 bg-light rounded-3 col-xl-4 border">
                <div class="mb-3 text-center">
                    <img src=" <?php echo e(Vite::asset('resources/images/kue bagian atas.png')); ?>"alt="" width="110%" height="110px"><br><br>
                    <h4>Detail Item</h4>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="itemCode" class="form-label">Item Code</label>
                        <h5><?php echo e($menus->item_code); ?></h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="itemName" class="form-label">Item Name</label>
                        <h5><?php echo e($menus->item_name); ?></h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="price" class="form-label">Price</label>
                        <h5><?php echo e($menus->price); ?></h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="itemDescription" class="form-label">Item Description</label>
                        <h5><?php echo e($menus->item_description); ?></h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <h5><?php echo e($menus->quantity->quantity_name); ?></h5>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 d-grid">
                        <a href="<?php echo e(route('menu.index')); ?>" class="btn btn-outline-dark btn-lg mt-3"><i class="bi-arrow-left-circle me-2"></i> Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Python\00 - Template\SEMESTER 4\masterBarangUts1\resources\views/menu/show.blade.php ENDPATH**/ ?>