<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row mb-0">
            <div class="col-lg-9 col-xl-10">
                <h4 class="mb-3"><?php echo e($pageTitle); ?></h4>
            </div>
            <div class="col-lg-3 col-xl-2">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('menu.create')); ?>" class="btn text-white" style="background-color: burlywood">Add Menu</a>
                </div>
            </div>
        </div>
        <hr>
        <div class="table-responsive border p-3 rounded-3">
            <table class="table table-bordered table-hover table-striped mb-0 bg-white">
                <thead>
                    <tr>
                        <th>Item Code</th>
                        <th>Item Name</th>
                        <th>Price</th>
                        <th>Item Description</th>
                        <th>Quantity</th>
                        <th> </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($menu->item_code); ?></td>
                        <td><?php echo e($menu->item_name); ?></td>
                        <td><?php echo e($menu->price); ?></td>
                        <td><?php echo e($menu->item_description); ?></td>
                        <td><?php echo e($menu->quantity_id); ?></td>
                        <td>
                            <div class="d-flex">
                            <a href="<?php echo e(route('menu.show', ['menu' => $menu->id])); ?>" class="btn btn-outline-dark btn-sm me-2"><i class="bi-person-lines-fill"></i></a>
                            <a href="<?php echo e(route('menu.edit', ['menu'=>$menu->id])); ?>" class="btn btn-outline-dark btn-sm me-2"><i class="bi-pencil-square"></i></a>
                            <div>
                                <div>
                                    <form action="<?php echo e(route('menu.destroy',['menu' =>$menu->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-outline-dark btn-sm me-2"><i class="bi-trash"></i></button>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div><br><br>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Python\00 - Template\SEMESTER 4\masterBarangUts1\resources\views/menu/index.blade.php ENDPATH**/ ?>