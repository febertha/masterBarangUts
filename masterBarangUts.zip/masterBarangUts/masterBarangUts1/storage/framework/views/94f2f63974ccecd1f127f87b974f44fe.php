<div class="footer">
    <div class="card text-center">
        <div class="card-header" style="background-color: burlywood">
            ©CakeHouse
        </div>
    </div>
</div>
<?php /**PATH C:\Users\user\Documents\Python\00 - Template\SEMESTER 4\masterBarangUts1\resources\views/layouts/footer.blade.php ENDPATH**/ ?>