<div class="footer">
    <div class="card text-center">
        <div class="card-header" style="background-color: burlywood">
            ©CakeHouse
        </div>
    </div>
</div>
