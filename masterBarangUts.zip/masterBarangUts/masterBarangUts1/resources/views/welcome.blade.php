<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Home</title>
    @vite('resources/sass/app.scss')
    @vite('resources/sass/welcome.scss')
</head>
<body>
    <nav class="navbar navbar-expand-md navbar-dark" style="background-color: burlywood">
        <div class="container">
            <a href="{{ route('home') }}" class="navbar-brand mb-0 h1"><img src="{{ Vite::asset('resources/images/logo cake house.png') }}" alt="image" style="width: 90px"></a>

            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <hr class="d-lg-none text-white-50">

                <hr class="d-lg-none text-white-50">

                <a href="{{ route('contactUs') }}" class="btn btn-outline-light my-2 ms-md-auto"><i class="bi-person-circle me-1"></i>Contact Us</a>
            </div>
        </div>
    </nav>
    <div class="container text-center my-5">
        <div class="col-md-12">
            <img src=" {{ Vite::asset('resources/images/kue depan.png') }}"alt="" width="35%"><br><br>
        <h1 class="mb-4"><p class="font-italic">WELCOME HOME SWEETIES!</p></h1>
        <h4>Are you not in the mood? Sweet cake is suitable for you</h4>
        </div>

        <div class="col-md-2 offset-md-5 mt-4">
            <div class="d-grid gap-2">
                <a class="btn btn-warning btn-outline-dark" href="home">More Info</a>
            </div>
        </div>
        <br><br><br>
        <div class="col-md-12 mt-5">
            <div class="main-body">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex flex-column align-items-center text-center">
                                    <img src=" {{ Vite::asset('resources/images/avatar.jpeg') }}"alt=""
                    class="rounded img-fluid" style="width: 150px;">
                                    <div class="mt-3">
                                        <h4>Febertha Atiek W</h4>
                                        <p class="text-secondary mb-1">Student at Telkom</p>
                                        <p class="text-muted font-size-sm">Surabaya, Indonesia</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="bg-light text-center text-lg-start">
        <!-- Copyright -->
        <div class="text-center p-3" style="background-color:burlywood">
            ©CakeHouse
        </div>
    </footer>
    @vite('resources/js/app.js')
</body>
</html>
