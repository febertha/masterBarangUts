@extends('layouts.app')

@section('content')
    <div class="container-sm my-5">
            <div class="row justify-content-center">
                <div class="container-sm mt-5">
                    <form action="{{ route('menu.update', ['menu' => $menus->id]) }}" method="POST">
                        @csrf
                        @method('put')
                        <div class="row justify-content-center">
                            <div class="p-5 bg-light rounded-3 border col-xl-6">
                                <img class="img-thumbnail" src="{{ Vite::asset('resources/images/kue bagian atas.png') }}" alt="image" width="100%"><br><br>
                                <div class="mb-3 text-center">
                                    <h4>Edit Menu</h4>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="item_code" class="form-label">Item Code</label>
                                        <input class="form-control @error('item_code') is-invalid @enderror" type="text" name="item_code" id="item_code" value="{{ $errors->any() ? old('item_code') : $menus->item_code }}" placeholder="Enter Item Code">
                                        @error('item_code')
                                            <div class="text-danger"><small>{{ $message }}</small></div>
                                        @enderror
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="item_name" class="form-label">Item Name</label>
                                        <input class="form-control @error('item_name') is-invalid @enderror" type="text" name="item_name" id="item_name" value="{{ $errors->any() ? old('item_name') : $menus->item_name }}" placeholder="Enter Item Name">
                                        @error('item_name')
                                            <div class="text-danger"><small>{{ $message}}</small></div>
                                        @enderror
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="price" class="form-label">Price</label>
                                        <input class="form-control @error('price') is-invalid @enderror" type="text" name="price" id="price" value="{{ $errors->any() ? old('price') : $menus->price }}" placeholder="Enter Price">
                                        @error('price')
                                            <div class="text-danger"><small>{{ $message }}</small></div>
                                        @enderror
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="item_description" class="form-label">Item Description</label>
                                        <input class="form-control @error('item_description') is-invalid @enderror" type="text" name="item_description" id="item_description" value="{{ $errors->any() ? old('item_description') : $menus->item_description }}" placeholder="Enter Item Description">
                                        @error('item_description')
                                            <div class="text-danger"><small>{{ $message }}</small></div>
                                        @enderror
                                    </div>
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="quantity" class="form-label">Quantity</label>
                                        <select name="quantity" id="quantity" class="form-select">
                                            @php
                                                $selected = "";
                                                if ($errors->any())
                                                    $selected = old('quantity');
                                                else
                                                    $selected = $menus->quantity_id;
                                            @endphp
                                            @foreach ($quantities as $quantity)
                                                <option value="{{ $quantity->id }}" {{ $selected == $quantity->id ? 'selected' : '' }}>{{ $quantity->quantity_code.' - '.$quantity->quantity_name }}</option>
                                            @endforeach
                                        </select>
                                        @error('quantity')
                                            <div class="text-danger"><small>{{ $message }}</small></div>
                                        @enderror
                                    </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6 d-grid">
                                        <a href="{{ route('menu.index') }}" class="btn btn-outline-dark btn-lg mt-3"><i class="bi-arrow-left-circle me-2"></i> Cancel</a>
                                    </div>
                                    <div class="col-md-6 d-grid">
                                        <button type="submit" class="btn btn-lg mt-3" style="background-color: burlywood"><i class="bi-check-circle me-2"></i> Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
    </div>
    @include('layouts.footer')
@endsection
</body>
</html>
