@extends('layouts.app')

@section('content')
    <div class="container-sm my-5">
        <div class="row justify-content-center">
            <div class="p-5 bg-light rounded-3 col-xl-4 border">
                <div class="mb-3 text-center">
                    <img src=" {{ Vite::asset('resources/images/kue bagian atas.png') }}"alt="" width="110%" height="110px"><br><br>
                    <h4>Detail Item</h4>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="itemCode" class="form-label">Item Code</label>
                        <h5>{{ $menus->item_code }}</h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="itemName" class="form-label">Item Name</label>
                        <h5>{{ $menus->item_name }}</h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="price" class="form-label">Price</label>
                        <h5>{{ $menus->price }}</h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="itemDescription" class="form-label">Item Description</label>
                        <h5>{{ $menus->item_description }}</h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <h5>{{ $menus->quantity->quantity_name }}</h5>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 d-grid">
                        <a href="{{ route('menu.index') }}" class="btn btn-outline-dark btn-lg mt-3"><i class="bi-arrow-left-circle me-2"></i> Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('layouts.footer')
@endsection
</body>
</html>
