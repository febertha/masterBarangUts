@extends('layouts.app')

@section('content')
    <div class="container-sm my-5">
        <form action="{{ route('menu.store') }}" method="POST">
            @csrf
            <div class="row justify-content-center">
                <div class="p-5 bg-light rounded-3 border col-xl-6">
                    <div class="mb-3 text-center">
                        <img src=" {{ Vite::asset('resources/images/kue bagian atas.png') }}"alt="" width="100%" height="110px"><br><br>
                        <h4>Add Menu</h4>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="item_code" class="form-label">Item Code</label>
                            <input class="form-control @error('item_code') is-invalid @enderror" type="text" name="item_code" id="item_code" value="{{ old('item_code') }}" placeholder="Enter Item Code">
                            @error('item_code')
                                <div class="text-danger"><small>{{ $message }}</small></div>
                            @enderror
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="item_name" class="form-label">Item Name</label>
                            <input class="form-control @error('item_name') is-invalid @enderror" type="text" name="item_name" id="item_name" value="{{ old('item_name') }}" placeholder="Enter Item Name">
                            @error('item_name')
                                <div class="text-danger"><small>{{ $message }}</small></div>
                            @enderror
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="price" class="form-label">Price</label>
                            <input class="form-control @error('price') is-invalid @enderror" type="text" name="price" id="price" value="{{ old('[price]') }}" placeholder="Enter Price (in Rupiah)">
                            @error('price')
                                <div class="text-danger"><small>{{ $message }}</small></div>
                            @enderror
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="item_description" class="form-label">Item Description</label>
                            <input class="form-control @error('item_description') is-invalid @enderror" type="text" name="item_description" id="item_description" value="{{ old('item_description') }}" placeholder="Enter Item Description">
                            @error('item_description')
                                <div class="text-danger"><small>{{ $message }}</small></div>
                            @enderror
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="quantity" class="form-label">Quantity</label>
                            <select name="quantity" id="quantity" class="form-select">
                                @foreach ($quantities as $quantity)
                                    <option value="{{ $quantity->id }}" {{ old('quantity') == $quantity->id ? 'selected' : '' }}>{{ $quantity->quantity_code.' - '.$quantity->quantity_name }}</option>
                                @endforeach
                            </select>
                            @error('quantity')
                                <div class="text-danger"><small>{{ $message }}</small></div>
                            @enderror
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-6 d-grid">
                            <a href="{{ route('menu.index') }}" class="btn btn-outline-dark btn-lg mt-3"><i class="bi-arrow-left-circle me-2"></i> Cancel</a>
                        </div>
                        <div class="col-md-6 d-grid">
                            <button type="submit" class="btn btn-lg mt-3" style="background-color: burlywood"><i class="bi-check-circle me-2"></i> Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
@include('layouts.footer')
@endsection
</body>
</html>
