@extends('layouts.app')

@section('content')
<div class="header1">
    <div class="container mt-4">
        <div id="carouselExampleFade" class="carousel slide" data-bs-ride="carousel" style="width: 80%">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src=" {{ Vite::asset('resources/images/kue 1.png') }}"alt="" width="80%">
              </div>
              <div class="carousel-item">
                <img src=" {{ Vite::asset('resources/images/kue 2.png') }}"alt="" width="80%">
              </div>
              <div class="carousel-item">
                <img src=" {{ Vite::asset('resources/images/kue 3.png') }}"alt="" width="80%">
              </div>
              <div class="carousel-item">
                <img src=" {{ Vite::asset('resources/images/kue 4.png') }}"alt="" width="80%">
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next" style="width: 56%">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
        </div>
        <br><br>
    </div>
    <div class="deskripsi 1">
        <h2>Let's Buy Now!</h2>
        <h5>Celebrate beautiful moments with our cake collection.
            Made and prepared specially for you.
        </h5>
        <p>Get discounts and promos with applicable conditions</p>
    </div>
</div>

@include('layouts.footer')
@endsection
</body>
</html>
