<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\Menu;
use App\Models\Quantity;
use Illuminate\Validation\Rule;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pageTitle = 'Menu list';

        // ELOQUENT
            $menus = Menu::all();
            return view('menu.index', [
                'pageTitle' => $pageTitle,
                'menu' => $menus
            ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        $pageTitle = 'Create Menu';

        //ELOQUENT
        $quantities = Quantity::all();
        return view('menu.MenuCreate', compact('pageTitle', 'quantities'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $messages = [
            'required' => ':Attribute harus diisi.',
            'numeric' => 'Isi :attribute dengan angka',
            'item_code.unique' => 'kode barang sudah ada',
        ];

        $validator = Validator::make($request->all(), [
            'item_code' => 'required|unique:menus,item_code',
            'item_name' => 'required',
            'price' => 'required|numeric',
            'item_description' => 'required',
        ], $messages);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();


        }


        //ELOQUENT
        $menu = New Menu;
        $menu->item_code = $request->item_code;
        $menu->item_name = $request->item_name;
        $menu->price = $request->price;
        $menu->item_description = $request->item_description;
        $menu->quantity_id = $request->quantity;
        $menu->save();

        return redirect()->route('menu.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $pageTitle = 'Menu Detail';

        //ELOQUENT
        $menus = Menu::find($id);

        return view('menu.show', compact('pageTitle', 'menus'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $pageTitle = 'Edit Menu';

        // ELOQUENT
        $quantities = Quantity::all();
        $menus = Menu::find($id);

        return view('menu.edit', compact('pageTitle', 'quantities', 'menus'));

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $messages = [
            'required' => ':Attribute harus diisi.',
            'numeric' => 'Isi :attribute dengan angka',
            'item_code.unique' => 'This item code has been used',
        ];

        $validator = Validator::make($request->all(), [
            'item_code' => 'required',
            'item_name' => 'required',
            'price' => 'required|numeric',
            'item_description' => 'required',
        ], $messages);


        $validator->after(function ($validator) use ($request, $id) {
            $value = $request->input('item_code');
            $count = DB::table('menus')
                ->where('item_code', $value)
                ->where('id', '<>', $id)
                ->count();

            if ($count > 0) {
                $validator->errors()->add('item_code', 'This item code has been used.');
            }
        });

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }


        // ELOQUENT
        $menu = Menu::find($id);
        $menu ->item_code = $request->item_code;
        $menu ->item_name = $request->item_name;
        $menu ->price = $request->price;
        $menu ->item_description = $request->item_description;
        $menu ->quantity_id = $request->quantity;
        $menu ->save();

        return redirect()->route('menu.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {

    // ELOQUENT
    Menu::find($id)->delete();

    return redirect()->route('menu.index');
    }
}
