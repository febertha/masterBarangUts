<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('menus')->insert([
            [
                'item_code' => 'A001',
                'item_name' => 'Chocolate De Ville',
                'price' => 350000,
                'item_description' => 'Chocolate cake that uses 85% dark choco',
                'quantity_id' => 'AB'
            ],
            [
                'item_code' => 'A002',
                'item_name' => 'Strawberry Cheeseckae',
                'price' => 230000,
                'item_decription' => 'Cake with blend of strawberry with cheese',
                'quantity_id' => 'AB'
            ],
            [
                'item_code' => 'A003',
                'item_name' => 'Blueberry Bloom',
                'price' => 68000,
                'item_description' => 'Cake with a blend of blueberry with cheese',
                'quantity_id' => 'Pcs'
            ],
            [
                'item_code' => 'A004',
                'item_name' => 'Chocolate Mandarin',
                'price' => 65000,
                'item_description' => 'Cake with a blend of Mandarin orange with choco',
                'quantity_id' => 'Pcs'
            ],
        ]);
    }
}
