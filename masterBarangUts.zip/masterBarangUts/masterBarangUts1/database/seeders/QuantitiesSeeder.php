<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class QuantitiesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('quantities')->insert([
            [
                'quantity_code' => 'AB',
                'quantity_name' => 'A Box',
            ],
            [
                'quantity_code' => 'Pcs',
                'quantity_name' => 'Pieces',
            ],
        ]);
    }
}
